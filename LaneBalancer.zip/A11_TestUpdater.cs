using System;
using ICities;
using UnityEngine;

namespace CS1_LaneBalancer
{
    public class TestUpdater : MonoBehaviour
    {
        void Update()
        {
            HudData.ClearRows();

            // [PATCH:10_HUD_ROWS_START]
HudRow rSeed = new HudRow("SEED");
rSeed.Add("seg=" + A11_RepathController.CorridorSeedSeg);
HudData.AddRow(rSeed);

HudRow rCap = new HudRow("CAP");
rCap.Add(A11_RepathController.CaptureRemainHud);
HudData.AddRow(rCap);

HudRow rScan = new HudRow("SCAN");
rScan.Add(A11_RepathController.HudLine0);
HudData.AddRow(rScan);

HudRow rRep = new HudRow("REP");
rRep.Add(A11_RepathController.HudLine1);
HudData.AddRow(rRep);

HudRow rState = new HudRow("STATE");
rState.Add(A11_RepathController.HudLine2);
HudData.AddRow(rState);
// [PATCH:10_HUD_ROWS_END]
        }
    }
}