# -*- coding: utf-8 -*-
import os
import sys
import shutil


def read_text(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write_text(path, text):
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def fail(msg):
    print("[PATCH-ERROR] " + msg)
    sys.exit(1)


def info(msg):
    print("[PATCH] " + msg)


def ensure_file(path, label):
    if not os.path.isfile(path):
        fail("%s nicht gefunden: %s" % (label, path))


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def backup_file(src_path, backup_dir):
    ensure_dir(backup_dir)
    dst = os.path.join(backup_dir, os.path.basename(src_path))
    shutil.copy2(src_path, dst)
    info("Backup: %s" % dst)


def find_unique_marker_block(text, marker_name, file_path):
    start_marker = "// [PATCH:%s_START]" % marker_name
    end_marker = "// [PATCH:%s_END]" % marker_name

    start_count = text.count(start_marker)
    end_count = text.count(end_marker)

    if start_count == 0:
        fail("START marker nicht gefunden: %s in %s" % (start_marker, file_path))
    if end_count == 0:
        fail("END marker nicht gefunden: %s in %s" % (end_marker, file_path))

    if start_count != 1:
        fail("START marker %d-mal gefunden (erwartet genau 1): %s in %s" %
             (start_count, start_marker, file_path))
    if end_count != 1:
        fail("END marker %d-mal gefunden (erwartet genau 1): %s in %s" %
             (end_count, end_marker, file_path))

    start_idx = text.find(start_marker)
    end_idx = text.find(end_marker)

    if end_idx < start_idx:
        fail("END marker liegt vor START marker: %s in %s" % (marker_name, file_path))

    start_block = start_idx + len(start_marker)
    return start_marker, end_marker, start_idx, start_block, end_idx


def replace_block(file_path, marker_name, patch_path, backup_dir):
    ensure_file(file_path, "Zieldatei")
    ensure_file(patch_path, "Patchdatei")

    text = read_text(file_path)
    new_block = read_text(patch_path)

    if new_block.strip() == "":
        fail("Patchdatei ist leer: %s" % patch_path)

    start_marker, end_marker, start_idx, start_block, end_idx = find_unique_marker_block(
        text, marker_name, file_path
    )

    backup_file(file_path, backup_dir)

    replacement = "\n" + new_block.rstrip() + "\n"
    new_text = text[:start_block] + replacement + text[end_idx:]

    write_text(file_path, new_text)
    info("REPLACED: %s %s" % (os.path.basename(file_path), marker_name))


def delete_block(file_path, marker_name, backup_dir):
    ensure_file(file_path, "Zieldatei")

    text = read_text(file_path)

    start_marker, end_marker, start_idx, start_block, end_idx = find_unique_marker_block(
        text, marker_name, file_path
    )

    backup_file(file_path, backup_dir)

    new_text = text[:start_block] + "\n\n" + text[end_idx:]
    write_text(file_path, new_text)
    info("DELETED: %s %s" % (os.path.basename(file_path), marker_name))


def validate_block(file_path, marker_name):
    ensure_file(file_path, "Zieldatei")

    text = read_text(file_path)
    find_unique_marker_block(text, marker_name, file_path)
    info("VALID: %s %s" % (os.path.basename(file_path), marker_name))


def main():
    if len(sys.argv) < 4:
        print("Usage:")
        print("  PATCH_APPLY.py replace  <file> <marker> <patchfile> <backupdir>")
        print("  PATCH_APPLY.py delete   <file> <marker> <backupdir>")
        print("  PATCH_APPLY.py validate <file> <marker>")
        sys.exit(1)

    mode = sys.argv[1].strip().lower()

    if mode == "replace":
        if len(sys.argv) != 6:
            fail("replace braucht: <file> <marker> <patchfile> <backupdir>")
        file_path = sys.argv[2]
        marker = sys.argv[3]
        patch_path = sys.argv[4]
        backup_dir = sys.argv[5]
        replace_block(file_path, marker, patch_path, backup_dir)

    elif mode == "delete":
        if len(sys.argv) != 5:
            fail("delete braucht: <file> <marker> <backupdir>")
        file_path = sys.argv[2]
        marker = sys.argv[3]
        backup_dir = sys.argv[4]
        delete_block(file_path, marker, backup_dir)

    elif mode == "validate":
        if len(sys.argv) != 4:
            fail("validate braucht: <file> <marker>")
        file_path = sys.argv[2]
        marker = sys.argv[3]
        validate_block(file_path, marker)

    else:
        fail("Unbekannter Modus: %s" % mode)


if __name__ == "__main__":
    main()