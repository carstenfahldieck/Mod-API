---
name: Translations
about: Help us translate TM:PE to all languages...
labels: Localisation, triage
---

<!-- First time? See our localisation guide: https://bit.ly/tmpe-localisation -->

### Language name or ISO code



### Localization file

<!-- Drag file below, or post URL to file, or, if you prefer, send a Pull Request -->



### Notes or questions?
