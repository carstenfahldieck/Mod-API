---
name: Feature Request
about: Share your ideas to make the mod even better...
labels: feature, triage
---

### Describe your idea



### Screenshots?

<!-- You can paste an image, or drag an image file, or paste URLs to images -->
<!-- How to take screenshots? See: https://bit.ly/2Kc8owO -->



### Notes or questions?
