namespace CSUtil.Commons {
    public enum ArrowDirection {
        None = 0,
        Left = 1,
        Forward = 2,
        Right = 3,
        Turn = 4,
    }
}