namespace TrafficManager.API.Manager {
    using TrafficManager.API.Traffic.Enums;

    public interface ICustomSegmentLightsManager {
    }
}