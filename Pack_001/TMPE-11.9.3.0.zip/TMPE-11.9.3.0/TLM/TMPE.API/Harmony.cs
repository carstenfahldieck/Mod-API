namespace TrafficManager.API {
    public class Harmony {
        public const string HARMONY_ID = "me.tmpe";
        public const string HARMONY_ID_PATHFINDING = "me.tmpe.pathfinding";
        public const string HARMONY_ID_PRELOAD = "me.tmpe.preload";
    }
}