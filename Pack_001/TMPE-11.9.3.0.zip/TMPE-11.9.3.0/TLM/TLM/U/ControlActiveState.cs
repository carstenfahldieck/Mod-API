namespace TrafficManager.U {
    /// <summary>
    /// Used by ButtonSkin to select appropriate sprites.
    /// </summary>
    public enum ControlActiveState {
        Normal,
        Active,
    }
}