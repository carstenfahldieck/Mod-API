namespace TrafficManager.Patch {
    using System;
    public class PreloadPatchAttribute : Attribute { }
}