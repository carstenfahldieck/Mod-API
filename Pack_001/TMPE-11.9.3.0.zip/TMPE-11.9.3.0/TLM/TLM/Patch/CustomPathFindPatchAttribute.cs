namespace TrafficManager.Patch {
    using System;

    public class CustomPathFindPatchAttribute: Attribute {

    }
}