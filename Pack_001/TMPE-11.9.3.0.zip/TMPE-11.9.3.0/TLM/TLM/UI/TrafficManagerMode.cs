namespace TrafficManager.UI {
    public enum TrafficManagerMode {
        None = 0,
        Activated = 1,
    }
}