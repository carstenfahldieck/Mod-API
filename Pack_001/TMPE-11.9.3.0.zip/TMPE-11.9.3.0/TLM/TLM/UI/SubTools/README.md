# TM:PE -- /UI/SubTool
Tools that are selectable through the main menu. 
## Classes
- **JunctionRestrictionsTool**: Junction restrictions
- **LaneArrowTool**: Lane arrow changer
- **LaneConnectorTool**: Lane connector
- **ManualTrafficLightsTool**: Manual traffic lights
- **ParkingRestrictionsTool**: Parking restrictions
- **PrioritySignsTool**: Priority signs
- **SpeedLimitTool**: Speed limits
- **TimedTrafficLightTool**: Timed traffic lights
- **ToggleTrafficLightsTool**: Switch traffic lights
- **VehicleRestrictionsTool**: Vehicle restrictions