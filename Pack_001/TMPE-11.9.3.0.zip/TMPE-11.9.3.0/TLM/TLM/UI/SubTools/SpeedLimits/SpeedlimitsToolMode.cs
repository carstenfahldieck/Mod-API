﻿namespace TrafficManager.UI.SubTools.SpeedLimits {
    public enum SpeedlimitsToolMode {
        Segments,
        Lanes,
        Defaults,
    }
}