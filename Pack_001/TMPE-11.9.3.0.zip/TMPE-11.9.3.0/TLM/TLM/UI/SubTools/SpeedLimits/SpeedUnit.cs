namespace TrafficManager.UI.SubTools.SpeedLimits {
    public enum SpeedUnit {
        CurrentlyConfigured, // Currently selected in the options menu
        Kmph,
        Mph,
    }
}
