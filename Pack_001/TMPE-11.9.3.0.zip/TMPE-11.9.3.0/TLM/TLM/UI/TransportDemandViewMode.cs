namespace TrafficManager.UI {
    public enum TransportDemandViewMode {
        Incoming,
        Outgoing,
    }
}