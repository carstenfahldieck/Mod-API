using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TLM")]
[assembly: AssemblyProduct("TLM")]
[assembly: AssemblyDescription("A mod for Cities: Skylines that gives you more control over road and rail traffic in your city.")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("70591292-D092-4DC5-AFB9-3AA950E240BE")]
