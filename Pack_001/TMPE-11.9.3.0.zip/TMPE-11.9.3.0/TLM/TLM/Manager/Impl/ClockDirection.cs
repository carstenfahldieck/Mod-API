namespace TrafficManager.Manager.Impl {
    public enum ClockDirection {
        Clockwise,
        CounterClockwise,
    }
}
