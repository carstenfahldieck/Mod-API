﻿https://en.wikipedia.org/wiki/Panno_(typeface)

Panno is a Latin sans-serif typeface designed by Dutch typeface designer, 
Pieter van Rosmalen. It is one of two typefaces specially designed for South 
Korean traffic signs. (The other being Hangil, the Hangul counterpart.) 

Panno Sign is the first variant to be commercially released. Normal and rounded 
forms are available, and each form has two weights - Negative and Positive - to 
use against dark and bright backgrounds respectively. 
