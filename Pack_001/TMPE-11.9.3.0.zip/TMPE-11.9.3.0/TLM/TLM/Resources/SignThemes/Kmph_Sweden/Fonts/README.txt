﻿Downloaded from Swedish Traffic Administration website
Free to download for illustrations and print
https://transportstyrelsen.se/sv/vagtrafik/Trafikregler/Om-vagmarken/Teckensnitt/
