﻿Generic Chinese theme
=====================

Based on Mainland China theme and only replaces signs with text to have no text 
in them. Keeping the Stop 停 sign as it is fine in all/most Chinese dialects.

Source file is located in Kmph_China/China.svg