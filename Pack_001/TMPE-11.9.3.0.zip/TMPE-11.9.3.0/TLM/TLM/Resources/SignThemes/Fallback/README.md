﻿Fallback Road Signs Theme
=========================

This is an implicitly loaded road signs theme which is used as last resort when 
finding road signs.

NOTE: Speed limit road signs do not query Fallback theme, it is assumed that 
any current theme would provide all necessary numbered road signs.